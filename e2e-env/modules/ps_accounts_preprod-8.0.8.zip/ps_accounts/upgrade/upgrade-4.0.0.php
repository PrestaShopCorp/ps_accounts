<?php

/**
 * @param Ps_accounts $module
 */
function upgrade_module_4_0_0($module)
{
    return true;
}
