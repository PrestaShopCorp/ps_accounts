<?php
/**
 * @param Ps_accounts $module
 *
 * @return bool
 */
function upgrade_module_8_0_5($module)
{
    return true;
}
