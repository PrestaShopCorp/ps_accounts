<?php
/**
 * @param Ps_accounts $module
 *
 * @return bool
 */
function upgrade_module_8_0_3($module)
{
    return true;
}
