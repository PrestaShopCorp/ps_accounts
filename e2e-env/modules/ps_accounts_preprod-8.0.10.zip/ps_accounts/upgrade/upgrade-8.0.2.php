<?php
/**
 * @param Ps_accounts $module
 *
 * @return bool
 */
function upgrade_module_8_0_2($module)
{
    return true;
}
